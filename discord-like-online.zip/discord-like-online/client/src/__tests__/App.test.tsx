import React from 'react'
import { render } from '@testing-library/react'
import { describe, it, expect } from 'vitest'
import App from '../App'

describe('smoke', ()=>{ it('renders', ()=>{ render(<App />); expect(true).toBe(true); }) })
