import React from 'react'
export default function App(){ return (<div style={{padding:20,color:'#ddd',background:'#0f1720',height:'100vh'}}>Discord-like minimal client<br/>Open console for WebRTC activity.</div>) }
