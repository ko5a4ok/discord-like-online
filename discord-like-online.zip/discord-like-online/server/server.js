// server.js - minimal express + socket.io + simple auth (for demo only)
require('dotenv').config();
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const mongoose = require('mongoose');
const authRoutes = require('./auth');
const signaling = require('./signaling');

const app = express();
app.use(express.json());
app.use('/auth', authRoutes);

app.get('/', (req, res) => res.send('Discord-like server is running'));

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });
signaling(io);

const MONGO = process.env.MONGO_URI || 'mongodb://localhost:27017/discordlike';
mongoose.connect(MONGO).then(()=> console.log('Mongo connected')).catch(err=> console.log('Mongo not connected', err));

const PORT = process.env.PORT || 4000;
server.listen(PORT, ()=> console.log('Server listening on', PORT));
