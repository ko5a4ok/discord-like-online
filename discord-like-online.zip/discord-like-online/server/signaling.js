// signaling.js - socket.io handlers for simple signaling
module.exports = function(io){
  io.on('connection', socket => {
    console.log('sock', socket.id);
    socket.on('join-room', ({room, username}) => {
      socket.join(room);
      socket.to(room).emit('user-joined', { id: socket.id, username });
    });
    socket.on('signal', ({ to, from, data }) => {
      if(to === 'room') {
        socket.to(data.room || '').emit('signal', { from, data });
        socket.broadcast.emit('signal', { from, data });
      } else {
        io.to(to).emit('signal', { from, data });
      }
    });
    socket.on('disconnect', ()=>{});
  });
};
