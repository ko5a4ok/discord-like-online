// auth.js - minimal (not production ready)
const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const User = require('./models/User');
const JWT_SECRET = process.env.JWT_SECRET || 'secret123';

router.post('/register', async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) return res.status(400).json({ error: 'missing' });
  const exists = await User.findOne({ username });
  if (exists) return res.status(400).json({ error: 'exists' });
  const hash = await bcrypt.hash(password, 10);
  const user = await User.create({ username, password: hash });
  const token = jwt.sign({ id: user._id, username }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, username });
});

router.post('/login', async (req, res) => {
  const { username, password } = req.body;
  const user = await User.findOne({ username });
  if (!user) return res.status(400).json({ error: 'no user' });
  const ok = await bcrypt.compare(password, user.password);
  if (!ok) return res.status(400).json({ error: 'bad pw' });
  const token = jwt.sign({ id: user._id, username }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, username });
});

module.exports = router;
